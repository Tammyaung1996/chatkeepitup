import { LinearProgress } from "@mui/material";

export const LoadingLine = () => {
  return <LinearProgress color="primary" />;
};
