
# TalkiChat

Realtime chat app using MERN stack




## Features

- Realtime messages
- Group chat
- Active status


## Demo

https://talkichat.netlify.app

